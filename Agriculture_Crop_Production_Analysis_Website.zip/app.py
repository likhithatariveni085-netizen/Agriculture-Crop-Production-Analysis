from flask import Flask, render_template, request
import pandas as pd
import os

app = Flask(__name__)
DATA_PATH = os.path.join(os.path.dirname(__file__), "crop_production_sample.csv")

def load_data():
    df = pd.read_csv(DATA_PATH)
    required = {"State", "Crop", "Year", "Area_Hectares",
                "Yield_Tonnes_per_Hectare", "Production_Tonnes"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError("Dataset is missing columns: " + ", ".join(sorted(missing)))
    return df

@app.route("/")
def index():
    df = load_data()
    crops = sorted(df["Crop"].dropna().unique().tolist())
    states = sorted(df["State"].dropna().unique().tolist())
    years = sorted(int(y) for y in df["Year"].dropna().unique())

    crop = request.args.get("crop", "All")
    state = request.args.get("state", "All")
    year = request.args.get("year", "All")

    filtered = df.copy()
    if crop != "All" and crop in crops:
        filtered = filtered[filtered["Crop"] == crop]
    else:
        crop = "All"
    if state != "All" and state in states:
        filtered = filtered[filtered["State"] == state]
    else:
        state = "All"
    if year != "All":
        try:
            year_num = int(year)
            filtered = filtered[filtered["Year"] == year_num]
            year = str(year_num)
        except ValueError:
            year = "All"

    total_production = float(filtered["Production_Tonnes"].sum()) if not filtered.empty else 0
    total_area = float(filtered["Area_Hectares"].sum()) if not filtered.empty else 0
    avg_yield = float(filtered["Yield_Tonnes_per_Hectare"].mean()) if not filtered.empty else 0
    crop_summary = (filtered.groupby("Crop")["Production_Tonnes"].sum()
                    .sort_values(ascending=False))
    chart_labels = crop_summary.index.tolist()
    chart_values = [round(float(v), 2) for v in crop_summary.values]
    yearly = (filtered.groupby("Year")["Production_Tonnes"].sum().sort_index())
    year_labels = [str(int(y)) for y in yearly.index.tolist()]
    year_values = [round(float(v), 2) for v in yearly.values]
    rows = filtered.sort_values(["Year", "State", "Crop"]).to_dict(orient="records")
    return render_template(
        "index.html",
        crops=crops, states=states, years=years,
        selected_crop=crop, selected_state=state, selected_year=year,
        total_production=total_production, total_area=total_area,
        avg_yield=avg_yield, chart_labels=chart_labels,
        chart_values=chart_values, year_labels=year_labels,
        year_values=year_values, rows=rows, record_count=len(filtered)
    )

if __name__ == "__main__":
    app.run(debug=True)
