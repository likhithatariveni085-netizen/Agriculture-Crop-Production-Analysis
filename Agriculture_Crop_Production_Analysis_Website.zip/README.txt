AGRICULTURE CROP PRODUCTION ANALYSIS WEBSITE

Built with Python Flask, Pandas, HTML, CSS and Chart.js.

RUN ON WINDOWS
1. Extract this ZIP file.
2. Open PowerShell in the extracted folder.
3. (Recommended) Create a virtual environment:
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
4. Install packages:
   pip install -r requirements.txt
5. Start the website:
   python app.py
6. Open this address in your browser:
   http://127.0.0.1:5000

IMPORTANT
- The included CSV contains illustrative sample values, not official statistics.
- Chart.js and Google Fonts are loaded from online CDNs, so charts/fonts need an internet connection.
- This is a local development demo. For public hosting, turn off debug mode and configure a production server.
